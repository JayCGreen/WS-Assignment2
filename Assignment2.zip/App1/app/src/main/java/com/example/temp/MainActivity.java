package com.example.temp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    int mode=0;

    public void modeSwitch(View v){
        boolean check = ((RadioButton) v).isChecked();
        switch (v.getId()){
            case R.id.TempMode:
                mode = 0;
                break;
            case R.id.DistMode:
                mode = 1;
                break;
            case R.id.VolMode:
                mode = 3;
                break;
            case R.id.WeightMode:
                mode = 2;
                break;
        }

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        final EditText imptext, metrtext;
        final RadioButton temp, dist, mass, vol;
        
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imptext = findViewById(R.id.ftxt);
        metrtext = findViewById(R.id.ctxt);
        temp = findViewById(R.id.TempMode);
        dist = findViewById(R.id.DistMode);
        mass = findViewById(R.id.WeightMode);
        vol = findViewById(R.id.VolMode);

        temp.setChecked(true);



        temp.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
            @Override
            public void onViewAttachedToWindow(View v) {

            }

            @Override
            public void onViewDetachedFromWindow(View v) {

            }
        });

        //ChangeMode When Button Pressed

        //Type int the Fahrenheit to change the metrsius

        imptext.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }


            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (imptext.hasFocus()) {
                    String ftxt = imptext.getText().toString();
                    switch (mode) {
                        case (0):

                            if (ftxt.length() > 0) {
                                float typed = Float.parseFloat(ftxt);
                                float convert = (typed - 32) * 5 / 9;
                                metrtext.setText("" + convert);
                            } else {
                                metrtext.setText("");
                            }
                            break;
                            //mile to km
                        case(1):
                            if (ftxt.length() > 0) {
                                float typed = Float.parseFloat(ftxt);
                                float convert = (float) ((typed ) * 1.60934);
                                metrtext.setText("" + convert);
                            } else {
                                metrtext.setText("");
                            }
                            break;
                            //lb to kg
                        case(2):
                            if (ftxt.length() > 0) {
                                float typed = Float.parseFloat(ftxt);
                                float convert = (float) ((typed ) * 0.453592);
                                metrtext.setText("" + convert);
                            } else {
                                metrtext.setText("");
                            }
                            break;
                            //gal to liter
                        case(3):
                            if (ftxt.length() > 0) {
                                float typed = Float.parseFloat(ftxt);
                                float convert = (float) ((typed ) * 3.78541);
                                metrtext.setText("" + convert);
                            } else {
                                metrtext.setText("");
                            }
                            break;
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable s) {


            }
        });

        //Type in metric block to change the imperial automatically

        metrtext.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (metrtext.hasFocus()) {
                    String ctxt = metrtext.getText().toString();
                    switch (mode) {
                        //celsius to fahrenheit
                        case (0):
                            if (ctxt.length() > 0) {
                                float typed = Float.parseFloat(ctxt);
                                float convert = typed * 9 / 5 + 32;
                                imptext.setText("" + convert);
                            } else {
                                imptext.setText("");
                            }
                            break;
                        //km to mile
                        case (1):
                            if (ctxt.length() > 0) {
                                float typed = Float.parseFloat(ctxt);
                                float convert = (typed) * (float)0.621371;
                                imptext.setText("" + convert);
                            } else {
                                imptext.setText("");
                            }
                            break;
                        //kg to lb
                        case (2):
                            if (ctxt.length() > 0) {
                                float typed = Float.parseFloat(ctxt);
                                float convert = (float) ((typed) * 2.20462);
                                imptext.setText("" + convert);
                            } else {
                                imptext.setText("");
                            }
                            break;
                        //liter to gal
                        case (3):
                            if (ctxt.length() > 0) {
                                float typed = Float.parseFloat(ctxt);
                                float convert = (float) ((typed) * 0.264172);
                                imptext.setText("" + convert);
                            } else {
                                imptext.setText("");
                            }
                            break;
                    }
                }
                }
            @Override
            public void afterTextChanged(Editable s) {



            }
        });








    }


}
